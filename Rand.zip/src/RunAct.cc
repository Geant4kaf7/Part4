#include <RunAct.hh>

// ���������� ������� �� ������ Run - ����� �������-Event, ����� ����������

RunAct::RunAct(std::ofstream& ofsa) 
{
 this->f_act=&ofsa;
 (*f_act) << std::setw(12) << "Hi from RunAct!" << std::endl;
// G4RunManager::GetRunManager()->SetRandomNumberStore(true);
 G4RunManager::GetRunManager()->SetRandomNumberStoreDir("random/"); 
 G4RunManager::GetRunManager()->GetRandomNumberStore();

 std::ostringstream os;
 os<<"beginOfRun_"<<G4Threading::G4GetThreadId()<<".rndm";
// G4Random::saveEngineStatus(os.str().c_str());
// G4Random::restoreEngineStatus(os.str().c_str());
}

RunAct::~RunAct()
{
 (*f_act) << std::setw(12) << "Bye from RunAct!" << std::endl;  
}

time_t Start, End;
int RunNum = 0;

void RunAct::BeginOfRunAction(const G4Run* aRun) 
{
 G4cout << "\n---Start------ Run # "<<RunNum<<" --------\n" <<"RunId="<<aRun->GetRunID()<< G4endl;
 time(&Start);
 struct tm *ptr;
 ptr = localtime(&Start);
 (*f_act) <<"ptr= "<< asctime(ptr) << G4endl;
}

void RunAct::EndOfRunAction(const G4Run* aRun) 
{
 time(&End);
 G4cout << " Time spent on this Run = " << difftime(End, Start)<<" seconds"<< G4endl;
 G4cout << "\n---Stop------ Run # "<<RunNum<<" --------\n" <<"RunId="<<aRun->GetRunID()<< G4endl;
 RunNum++;
}

#include <PrimaryPart.hh>

PrimaryPart::PrimaryPart(std::ofstream& ofsa)
{
 GProton = new G4ParticleGun(1);
 GProton->SetParticleDefinition(G4Proton::ProtonDefinition());
 G4double E0;
 char string[1000];
 std::ifstream init;
 init.open("./in/input.dat");
 init.getline(string,1000);
 init>>E0;
 init.close();
 GProton->SetParticleEnergy(E0 * MeV);
 this->f_prim=&ofsa;
 (*f_prim) << std::setw(12) << "Hi from PrimaryPart! " << GProton->GetParticleEnergy() << std::endl;
}

PrimaryPart::~PrimaryPart() 
{
 (*f_prim) << std::setw(12) << "Bye from PrimaryPart!" << std::endl;
}

//��������� ���������
void PrimaryPart::GeneratePrimaries(G4Event* anEvent) 
{
 G4double E0;
 char string[1000];
 std::ifstream init;
 init.open("./in/input.dat");
 init.getline(string,1000);
 init>>E0;
 init.close();
 GProton->SetParticleEnergy(E0 * MeV);
 G4double x_position=(G4UniformRand()-0.5)*20.*cm;
 G4double y_position=(G4UniformRand()-0.5)*2.*cm; 
 GProton->SetParticlePosition(G4ThreeVector(x_position, y_position, -5.*cm));
 GProton->SetParticleMomentumDirection(G4ThreeVector(0, 0, 1));
 GProton->GeneratePrimaryVertex(anEvent);
 
}


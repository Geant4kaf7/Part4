#ifndef FINAL_LOADER_HH
#define FINAL_LOADER_HH

#include "G4GlobalConfig.hh"	
//#ifdef G4MULTITHREADED
//#include "DataWriter.hh"
//#include <G4StepLimiter.hh>
//#include <G4UserLimits.hh>
//#include "G4UImanager.hh"
//#include <G4VisManager.hh>
///#include "G4MTRunManager.hh"
//#else
#include <fstream>
#include <G4StepLimiter.hh>
#include <G4UserLimits.hh>
#include "G4UImanager.hh"
#include <G4VisManager.hh>
#include "G4RunManager.hh"
//#endif

#include "G4UImanager.hh"
#include "QBBC.hh"
#include "G4StepLimiterPhysics.hh"

#include <iostream>
#include <iomanip>
#include <stdio.h>
//#ifdef G4VIS_USE
#include "G4VisExecutive.hh"
//#endif
//#ifdef G4UI_USE
#include "G4UIExecutive.hh"
//#endif

class Loader{
private:
  std::ofstream *ofs_sn;

//#ifdef G4MULTITHREADED
//    G4MTRunManager* runManager;
//#else
    G4RunManager* runManager;
//#endif

//#ifdef G4VIS_USE
    G4VisManager* visManager;
//#endif
public:
    Loader(int argc, char** argv, std::ofstream& fout);
    ~Loader();
};

#endif //FINAL_LOADER_HH
